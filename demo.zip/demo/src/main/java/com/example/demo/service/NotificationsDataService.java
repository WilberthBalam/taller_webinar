package com.example.demo.service;

import com.example.demo.model.NotificationsData;
import com.example.demo.repository.NotificationsDataRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class NotificationsDataService {

    @Autowired
    private NotificationsDataRepository notificationsDataRepository;

    @Autowired
    private SimpMessagingTemplate simpMessagingTemplate;

    public NotificationsDataService() {
    }

    public List<NotificationsData> getListNotifications() {
        List<NotificationsData> notificationsDataList = notificationsDataRepository.findAllByRemovedFalse();
        return notificationsDataList;
    }

    public NotificationsData saveNewNotifications(NotificationsData data) {
        NotificationsData notificationsData = notificationsDataRepository.save(data);
        sendDataUpdated(getListNotifications());
        return notificationsData;
    }

    public void sendDataUpdated(List<NotificationsData> notificationsData) {
        this.simpMessagingTemplate.convertAndSend("/topic/updateListNotifications", notificationsData);
    }
}
