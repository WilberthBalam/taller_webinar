package com.example.demo.controller;


import com.example.demo.model.NotificationsData;
import com.example.demo.service.NotificationsDataService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.DestinationVariable;
import org.springframework.messaging.simp.annotation.SubscribeMapping;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/demo")
public class NotificationsDataController {
    @Autowired
    private NotificationsDataService notificationsDataService;

    @SubscribeMapping("/topic/updateListNotifications")
    public void updateListNotifications(@DestinationVariable Long data){

    }

    @GetMapping("/getDataListNotifications")
    @ResponseBody
    public Map<String, Object> getDataListNotifications() {
        Map<String, Object> response = new HashMap<String, Object>();
        try {
            List<NotificationsData> notificationsData = notificationsDataService.getListNotifications();
            response.put("success", true);
            response.put("status", 200);
            response.put("data", notificationsData);
            return  response;
        } catch (Exception e) {
            e.printStackTrace();
            response.put("error", e.getMessage());
            response.put("status", 500);
            return response;
        }
    }

    @PostMapping("/saveDataNotification")
    @ResponseBody
    public Map<String, Object> saveDataNotification(@RequestBody NotificationsData notificationsData) {
        Map<String, Object> response = new HashMap();
        try{
            NotificationsData notificationsData1 = notificationsDataService.saveNewNotifications(notificationsData);
            response.put("success", true);
            response.put("status", 200);
            response.put("data", notificationsData1);
            return response;
        }catch (Exception e){
            e.printStackTrace();
            response.put("error", e.getMessage());
            response.put("status", 500);
            return response;
        }
    }
}
