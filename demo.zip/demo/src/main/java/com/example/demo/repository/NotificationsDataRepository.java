package com.example.demo.repository;

import com.example.demo.model.NotificationsData;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface NotificationsDataRepository extends JpaRepository<NotificationsData, Long> {
    List<NotificationsData> findAllByRemovedFalse();
}
