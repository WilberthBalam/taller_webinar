import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ListNotificationsComponent } from './components/list-notifications/list-notifications.component';
import { AddNotificationComponent } from './components/add-notification/add-notification.component';
import {NotificationsService} from './services/notifications.service';
import {SocketClientService} from './services/socket-client.service';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import {HttpClientModule} from '@angular/common/http';
import {FormsModule} from '@angular/forms';

@NgModule({
  declarations: [
    AppComponent,
    ListNotificationsComponent,
    AddNotificationComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgbModule,
    HttpClientModule,
    FormsModule,
  ],
  providers: [NotificationsService, SocketClientService],
  bootstrap: [AppComponent]
})
export class AppModule { }
