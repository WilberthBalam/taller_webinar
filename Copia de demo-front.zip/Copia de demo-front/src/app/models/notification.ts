export interface Notification {
  id: number;
  message: string;
  author: string;
  removed: boolean;
}
