import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {ListNotificationsComponent} from './components/list-notifications/list-notifications.component';
import {AddNotificationComponent} from './components/add-notification/add-notification.component';


const routes: Routes = [
  {
    path: '',
    children: [
      {
        path: 'list',
        component: ListNotificationsComponent,
      },
      {
        path: 'add',
        component: AddNotificationComponent,
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
