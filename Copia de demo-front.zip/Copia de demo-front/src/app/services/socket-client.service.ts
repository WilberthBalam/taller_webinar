import { Injectable } from '@angular/core';
import * as Stomp from 'stompjs';
import * as SockJS from 'sockjs-client';
import {Observable, Subject} from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class SocketClientService {
  private serverUrl = 'http://localhost:8081';
  private stompClient;
  private updateData$: Subject<any> = new Subject<any>();
  constructor() {
    this.intializeWebSocketConnection();
  }

  intializeWebSocketConnection() {
    console.log('ejecuto el codigo');
    const ws = new SockJS(this.serverUrl + '/ws');
    this.stompClient = Stomp.over(ws);
    this.stompClient.__proto__.debug = () => {};

    this.stompClient.connect({}, () => {
      this.stompClient.subscribe('/topic/updateListNotifications', (response) => {
        console.log(JSON.parse(response.body));
        this.setDataUpdated(JSON.parse(response.body));
      });
    });
  }

  setDataUpdated(data) {
    this.updateData$.next(data);
  }
  getDataUpdated$(): Observable<any> {
    return this.updateData$.asObservable();
  }

  errorCallBack(error) {
    console.log('errorCallBack --> ', error);
    setTimeout(() => {
      this.intializeWebSocketConnection();
    });
  }
}
