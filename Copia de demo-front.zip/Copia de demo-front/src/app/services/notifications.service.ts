import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {Observable} from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class NotificationsService {
  private REST_API_SERVER = 'http://localhost:8081';
  private headers = new HttpHeaders({
    'Content-Type': 'application/json'
  });
  constructor(public http: HttpClient) {}

  public getListNotifications(): Observable<any> {
      const url = this.REST_API_SERVER + '/demo/getDataListNotifications';
      return this.http.get(url, {headers: this.headers});
  }

  public saveDataNotification(body: any): Observable<any> {
    const url = this.REST_API_SERVER + '/demo/saveDataNotification';
    return this.http.post(url, body, {headers: this.headers});
  }
}
