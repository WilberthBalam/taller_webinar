import {Component, OnDestroy, OnInit} from '@angular/core';
import {NotificationsService} from '../../services/notifications.service';
import {Notification} from '../../models/notification';
import {take, takeUntil} from 'rxjs/operators';
import {SocketClientService} from '../../services/socket-client.service';
import {Subject} from 'rxjs';

@Component({
  selector: 'app-list-notifications',
  templateUrl: './list-notifications.component.html',
  styleUrls: ['./list-notifications.component.css']
})
export class ListNotificationsComponent implements OnInit,  OnDestroy{
  public listNotifications: Notification[] = [];
  destroy$: Subject<boolean> = new Subject<boolean>();
  constructor(public notificationService: NotificationsService, private socketClient: SocketClientService) {
    this.getDataTable();
    this.socketClient.getDataUpdated$().pipe(takeUntil(this.destroy$)).subscribe((response: any) => {
      if (response && response.length > 0) {
        this.listNotifications = response;
      }
    });
  }

  ngOnInit() {
  }
  public getDataTable() {
    this.notificationService.getListNotifications().pipe(take(1)).subscribe((response: any) => {
      if (response.status == 200) {
        this.listNotifications = response.data;
      }
    });
  }
  ngOnDestroy(): void {
    this.destroy$.next(true);
    this.destroy$.unsubscribe();
  }
}
