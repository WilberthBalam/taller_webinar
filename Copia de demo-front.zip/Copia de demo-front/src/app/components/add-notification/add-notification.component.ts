import { Component, OnInit } from '@angular/core';
import {Notification} from '../../models/notification';
import {NotificationsService} from '../../services/notifications.service';
@Component({
  selector: 'app-add-notification',
  templateUrl: './add-notification.component.html',
  styleUrls: ['./add-notification.component.css']
})
export class AddNotificationComponent implements OnInit {
  public newRecord: Notification = {} as Notification;
  constructor(public notificationService: NotificationsService) {
  }

  ngOnInit() {
  }

  public sendData() {
    this.newRecord.removed = false;
    this.notificationService.saveDataNotification(this.newRecord).subscribe((response: any) => {

    });
  }

}
